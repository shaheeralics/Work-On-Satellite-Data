# Remote Sensing Data > 2024-07-27 5:45pm
https://universe.roboflow.com/image-captioning-for-remote-sensingdata-0zids/remote-sensing-data

Provided by a Roboflow user
License: CC BY 4.0

